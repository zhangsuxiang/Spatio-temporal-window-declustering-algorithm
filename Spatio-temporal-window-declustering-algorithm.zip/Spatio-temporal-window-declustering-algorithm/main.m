clear all;close all;clc;
% 1. 读取数据
% 列：time(Year, month, day, hour, minute, second), lat, lon, M, value
data = load('test.txt');

% 列索引
col_time  = 1;
col_lat   = 2;
col_lon   = 3;
col_M     = 4;
col_value = 5;

% 2. 解析时间：'yyyyMMddHHmmss'
% 先把数值转换为字符串（确保 14 位，不会丢失前导零）
time_nums = data(:,col_time);
time_strs = arrayfun(@(x) sprintf('%014d',x), time_nums, 'UniformOutput', false);
times = datetime(time_strs, 'InputFormat','yyyyMMddHHmmss');

lats = data(:,col_lat);
lons = data(:,col_lon);
Ms   = data(:,col_M);
vals = data(:,col_value);

N = numel(times);

% 3. 设置去丛集参数
L_km      = 50;       % 空间窗半径（km）
T_pre     = days(7);   % 向前时间窗（天）
T_post    = days(1); % 向后时间窗（天）

isMain = true(N,1);

% 预先计算所有点间距离矩阵（球面距离，单位 km）
% 若有 Mapping Toolbox，可用 distance；否则用自定义 haversine
R = 6371;  % 地球半径 km
lat1 = deg2rad(lats);  lon1 = deg2rad(lons);
lat2 = lat1';          lon2 = lon1';
dlat = lat2 - lat1;
dlon = lon2 - lon1;
a = sin(dlat/2).^2 + cos(lat1).*cos(lat2).*sin(dlon/2).^2;
D = 2*R*asin(min(1,sqrt(a)));  % NxN 距离矩阵

% 4. 遍历每个事件
for i = 1:N
    idx_pre  = find(times >= times(i)-T_pre   & times < times(i));
    idx_post = find(times >  times(i)        & times <= times(i)+T_post);
    idx_win  = [idx_pre; idx_post];
    % 筛选空间窗内
    idx_win  = idx_win(D(i,idx_win) <= L_km);
    % 若窗内存在比当前事件更大震级，则标记为丛集
    if any(Ms(idx_win) > Ms(i))
        isMain(i) = false;
    end
end

% 5. 提取、保存主震目录
mainshocks.times = times(isMain);
mainshocks.lat   = lats(isMain);
mainshocks.lon   = lons(isMain);
mainshocks.M     = Ms(isMain);
mainshocks.value = vals(isMain);

% 5. 保存去丛集后的目录到 TXT 文件
outName = 'declustered.txt';
fid = fopen(outName, 'w');
if fid < 0
    error('无法打开输出文件 %s', outName);
end

% 循环写入
n = numel(mainshocks.times);
for i = 1:n
    % 将 datetime 再格式化回 ’yyyyMMddHHmmss‘
    tstr = datestr(mainshocks.times(i), 'yyyymmddHHMMSS');
    fprintf(fid, '%s %.5f %.5f %.2f %.4f\n', ...
        tstr, ...
        mainshocks.lat(i), ...
        mainshocks.lon(i), ...
        mainshocks.M(i), ...
        mainshocks.value(i));
end

fclose(fid);
fprintf('已将 %d 个主震写入 %s\n', n, outName);